
output "secret_value_private_key" {
  value = aws_secretsmanager_secret_version.secret_value_private_key.secret_string
}

output "secret_value_public_key" {
  value = aws_secretsmanager_secret_version.secret_value_public_key.secret_string
}


terraform {
  required_version = ">= 0.12, < 0.13"
}

provider "aws" {
  region = "eu-west-1"
  version = "~> 2.0"
}

resource "aws_secretsmanager_secret" "public_key_secret" {
  name = "public_key_payments_janus_terraform"
}

resource "aws_secretsmanager_secret" "private_key_secret" {
  name = "private_key_payments_janus_terraform"
}

resource "aws_secretsmanager_secret_version" "secret_value_private_key" {
  secret_id     = aws_secretsmanager_secret.private_key_secret.id
  secret_string = file("private_key.pem")
}

resource "aws_secretsmanager_secret_version" "secret_value_public_key" {
  secret_id     = aws_secretsmanager_secret.public_key_secret.id
  secret_string = file("public_key.pem")
}

